Fishing Explorer documented extract package

source.bundle.json preserves the original artifact object and original embedded file contents. manifest.json is the original artifact manifest. package-manifest.json records this packaging operation and checksums for every other member. Original source files retain their own hashes.

Start with query-summary.txt and data-dictionary.json. spreadsheet-data.csv is a separately labelled spreadsheet-oriented derivative with stronger formula protection; import identifiers as text. data.json retains normalized values and dimension types, and upstream-response.json retains the original provider text when available. data.csv remains the original stored CSV.

Keep the complete package together. Import through Saved extracts in Fishing Explorer. No token or network access is needed to reopen it. Package checksums are not publisher signatures or a grant of redistribution rights. See original caveats.txt, source-citation.txt and use-conditions.txt.
