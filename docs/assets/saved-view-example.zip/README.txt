Fishing Explorer saved-view export · format 1
SYNTHETIC DEMONSTRATION — not observations.
Original extract: d2becf45-a1ba-4f57-8175-fbb7ec19bc9c
Requested source/version: synthetic-activity / fixture-v1
Selected UTC window: 2024-01-01 → 2024-01-08 (end exclusive)
Original time-label filter: all saved labels
Group filter: TRAWLERS
Returned selected rows: 36 / 72
Returned selected total: 756 synthetic apparent fishing hours
Selected rows, group totals and complete selected time bins are exported, not just the visible table pages. Missing bins remain unavailable; percentages/fractions never use a hidden table-search subset as denominator.
query.json and boundary.geojson remain the original exact request. selection-manifest.json records the local filtering and parent hashes. source.bundle.json retains the original artifact and can be imported separately within the JSON import limit; use the original documented source ZIP for larger transfers. This selection ZIP is a derivative package, not an input to the documented-extract ZIP importer.
Use the data dictionary and original caveats. This transformation confers no additional use rights or observation confidence. Source cells are not fractionally clipped and missing records are not filled with zero.
