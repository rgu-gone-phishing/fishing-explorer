Fishing Explorer historical archive
See manifest.json for complete/partial status, missing windows, source, units and checksums. data/ contains spreadsheet-safe CSV derivatives. chunks/ contains original research bundles, including upstream responses and product caveats. Keep all files together.
Powered by Global Fishing Watch for GFW data: https://globalfishingwatch.org
API data use conditions: https://globalfishingwatch.org/our-apis/documentation/docs/license-rate-limits
Synthetic fixtures are not observations and must not be used for research.
