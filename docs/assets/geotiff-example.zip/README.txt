Fishing Explorer GIS export

SYNTHETIC DEMONSTRATION — not observations.
activity.tif is a locally generated derivative of saved records, not the original provider TIFF. One Float64 band sums the saved time/group selection recorded in raster-manifest.json. This is not density, catch or a distinct-vessel count.

CRS: EPSG:4326. North-up PixelIsArea grid; returned coordinates are centres. Cell edges extend half a grid interval around them. Missing pixels are NaN nodata; numeric zero remains zero. No interpolation, fractional clipping, reception correction or automatic coarsening. A populated pixel does not prove full temporal/group coverage.

Keep this package together. raster-manifest.json contains selection, geotransform, source hashes and checksums of every other member. query.json/boundary.geojson preserve the original query, not a raster-clipped replacement. source.bundle.json preserves the original complete extract and can be imported as a JSON bundle within that importer's size limit. This GIS ZIP is not a documented-extract ZIP input. Use the original documented extract ZIP for larger local transfers.

Source conditions remain applicable; this derivative grants no additional rights. See caveats.txt and use-conditions.txt. Checksums establish consistency, not publisher authenticity.
