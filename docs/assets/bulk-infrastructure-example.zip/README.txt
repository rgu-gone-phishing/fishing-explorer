Fishing Explorer bulk infrastructure archive · format 1
All three source files saved.
Requested dataset: public-fixed-infrastructure-data:v1.1
Reported dataset: public-fixed-infrastructure-data:v1.1
Selection: All source dates
Labels: all, including source noise and unavailable categories
Confidence categories: all
Structure ID filter: none
Area envelope west,south,east,north: 3.8, 52.28, 3.83, 52.3
Exact submitted geometry: snapshot.json → snapshot.query.geometry. Provider GEOM is separate and only verified when saved.
Local record: ff024d67-3ef9-48a6-aeb4-017ad17aff07
Remote report ID: 68e10164-a37d-40fa-b6ae-f2ccb90c185a
Recorded creation/submission time: 2026-10-24T06:48:38.476Z
Remote status: done
Local status: complete
CSV records inspected: 3
Saved files: GEOM, README, DATA
Missing files: none
Original compressed CSV, provider README and geometry retain their bytes and per-file hashes/receipt times in snapshot.json. Source administrative metadata is retained there as well.
The preview is a bounded prefix; the original CSV retains every transferred record. No local data normalization or inference is applied. CSV syntax/header checks do not independently validate scientific observations.
Keep this archive together. Checksums are consistency evidence, not publisher authentication or a permission grant. No personal token or signed storage URL is included.
Bulk detections are a separate, less-filtered product from the infrastructure map. Noise and additional regions may be included.
Rows describe source detections/records, not an authoritative installation inventory. Repeated structure IDs must not be counted as distinct structures.
Label confidence is a source category, not a probability of operation or fishing impact. Unavailable evidence is not low confidence.
Date filters select a structure’s first or last detection date. They do not select every individual detection date, continuous operation or activity during that interval.
All original fields and compressed data are retained. A local preview is a subset, not a complete map or absence test.
Stopping local retrieval does not cancel report generation at GFW. Reopening local work never resubmits a report automatically.
Powered by Global Fishing Watch: https://globalfishingwatch.org
Product: https://globalfishingwatch.org/our-apis/documentation/docs/v3/bulk-download
Use conditions: https://globalfishingwatch.org/our-apis/documentation/docs/license-rate-limits
